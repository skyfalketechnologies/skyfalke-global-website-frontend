1:"$Sreact.fragment"
2:I[65983,["/_next/static/chunks/edf73500bba4131a.js","/_next/static/chunks/c84bce233daf9f30.js","/_next/static/chunks/5bc13c60cb660167.js","/_next/static/chunks/049892f29479eb87.js","/_next/static/chunks/f77c75771af4773f.js","/_next/static/chunks/46a1d62badd0c0ac.js"],"default"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7738b2b176cf8288.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"1jjmU7sHIAxn14sYH4iv2","rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/46a1d62badd0c0ac.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
