1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:I[82332,["/_next/static/chunks/edf73500bba4131a.js","/_next/static/chunks/c84bce233daf9f30.js","/_next/static/chunks/5bc13c60cb660167.js","/_next/static/chunks/049892f29479eb87.js","/_next/static/chunks/f77c75771af4773f.js","/_next/static/chunks/5c51819bb5deabb0.js","/_next/static/chunks/45a7c6f05bc518c6.js"],"default"]
4:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/7738b2b176cf8288.js"],"OutletBoundary"]
0:{"buildId":"QWiMPt6wePOv6IY7f8r71","rsc":["$","$1","c",{"children":[["$","$2",null,{"fallback":["$","div",null,{"className":"min-h-screen flex items-center justify-center","children":["$","div",null,{"className":"animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"}]}],"children":["$","$L3",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/5c51819bb5deabb0.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/45a7c6f05bc518c6.js","async":true}]],["$","$L4",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
